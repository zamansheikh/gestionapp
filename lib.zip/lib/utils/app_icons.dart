class AppIcons {
  static var base = "assets/icons/";
  static String calenderIcon = "${base}calender.svg";
  static String reserveIcon = "${base}reserve.svg";
  static String profileIcon = "${base}profile.svg";
  static String register = "${base}register.svg";
}
